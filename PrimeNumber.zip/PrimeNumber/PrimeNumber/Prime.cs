﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PrimeNumber
{
    public static class Prime
    {
        public static List<int> GetAllPrimeNumbers(int numberOfPrimes)
        {
            if (numberOfPrimes < 1)
            {
                throw new ArgumentOutOfRangeException("number must be > 1");
            }
            List<int> primes = new List<int>();
            primes.Add(2);
            int nextPrime = 3;
            while (primes.Count < numberOfPrimes)
            {
                int sqrt = (int)Math.Sqrt(nextPrime);
                bool isPrime = true;
                for (int i = 0; (int)primes[i] <= sqrt; i++)
                {
                    if (nextPrime % primes[i] == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime)
                {
                    primes.Add(nextPrime);
                }
                nextPrime += 2;
            }
            return primes;
        }
    }
}

