﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrimeNumber
{
    public static class MultiplicationTable
    {
        public static List<List<int>> returnTable(List<int> primes)
        {
            // returns 2d  list of multipication of prime number
           var table = new List<List<int>>();
            int index = 0;
            foreach (int p in primes)
            {
                table.Add(new List<int>());
                foreach (int j in primes)
                {
                    table[index].Add(p * j);
                }
                index++;
            }
            return table;
        }
    }
}
