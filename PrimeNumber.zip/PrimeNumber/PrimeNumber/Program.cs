﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PrimeNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            // get the number from console
            Console.WriteLine("Please enter a count of a prime number: ");
            var num = Convert.ToInt32(Console.ReadLine());

            //GetAllPrimeNumbers method will generate the prime numbers list of entered number.
            var primes = Prime.GetAllPrimeNumbers(num);

            // returnTable method will return (n+1) * (n+1) in form of 2d  list
            var multTable = MultiplicationTable.returnTable(primes);

            // this line of code will add blank coloum or top first column blank 
            Console.Write("{0,0}{1,7}", "|", "|");
            foreach (int p in primes)
            {
                // this line will print top first row that contains all prime numbers
                Console.Write("{0,5}{1,2}", p, "|");
            }

            // this line is used to add new line 
            Console.WriteLine();
            for (int i = 0; i < multTable.Count(); i++)
            {
                // this line will print first column that contains all prime numbers
                Console.Write("{0,0}{1,5}{2,2}", "|", primes[i], "|");
                for (int j = 0; j < multTable.Count(); j++)
                {
                    // this line will print multipication of prime numbers
                    Console.Write("{0,5}{1,2}", multTable[i][j], "|");
                }
                Console.WriteLine();
            }
        }
    }
}
