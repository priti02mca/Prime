using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using PrimeNumber;

namespace PrimeTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestPrime1()
        {
            List<int> primes = Prime.GetAllPrimeNumbers(1);
            Assert.AreEqual((int)2, primes[0]);
        }

        [TestMethod]
        public void TestPrimes5()
        {
            List<int> primes = Prime.GetAllPrimeNumbers(5);
            List<int> expected = new List<int>() { (int)2, (int)3, (int)5, (int)7, (int)11 };
            CollectionAssert.AreEqual(expected, primes);
        }

        [TestMethod]
        public void TestPrimes10()
        {
            List<int> primes = Prime.GetAllPrimeNumbers(10);
            List<int> expected = new List<int>() { (int)2, (int)3, (int)5, (int)7, (int)11, (int)13, (int)17, (int)19, (int)23, (int)29 };
            CollectionAssert.AreEqual(expected, primes);
        }

        [TestMethod]
        public void TestMultiplication3()
        {
            List<int> primeList = new List<int>() { (int)2, (int)3, (int)5 };
            List<List<int>> returned = MultiplicationTable.returnTable(primeList);
            List<List<int>> expected = new List<List<int>>();
            expected.Add(new List<int> { (int)4, (int)6, (int)10 });
            expected.Add(new List<int> { (int)6, (int)9, (int)15 });
            expected.Add(new List<int> { (int)10, (int)15, (int)25 });
            CollectionAssert.AreEqual(expected[0], returned[0]);
            CollectionAssert.AreEqual(expected[1], returned[1]);
            CollectionAssert.AreEqual(expected[2], returned[2]);
        }
    }
}
